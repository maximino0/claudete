class Fornecedor {
    #nome
    #fone
    constructor(nome="Pedro", fone="(00)00000-0000") {
        this.#nome = nome
        this.#fone = fone
    }
    setNome(novoNome) {
        this.#nome = novoNome;
    }
    getNome() {
        return this.#nome;
    }
    setFone(novoFone) {
        this.#fone = novoFone;
    }
    getFone() {
        return this.#fone;
    }
}

export default Fornecedor

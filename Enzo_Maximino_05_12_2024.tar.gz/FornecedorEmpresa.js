import Fornecedor from './Fornecedor.js'
class FornecedorPessoa extends Fornecedor{
    #cnpj
    #le
    constructor(nome="Pedro", fone="(00)00000-0000", cnpj="12.125.123-56", le="132.410.123-02") {
        super(nome,fone)
        this.#cnpj = cnpj
        this.#le = le
    }
    setCnpj(novocnpj) {
        this.#cnpj = novocnpj;
    }
    getCnpj() {
        return this.#cnpj;
    }
    setLe(novole) {
        this.#le = novole;
    }
    getLe() {
        return this.#le;
    }
}

export default FornecedorPessoa
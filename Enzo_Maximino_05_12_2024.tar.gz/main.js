import Fornecedor from "./FornecedorPessoa.js";
import FornecedorPessoa from "./FornecedorPessoa.js";

const Pedro = new Fornecedor()
console.log(Pedro.getNome())
const Augusto = new FornecedorPessoa()
console.log(Augusto.getNome())
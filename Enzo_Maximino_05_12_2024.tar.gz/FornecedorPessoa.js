import Fornecedor from './Fornecedor.js'
class FornecedorPessoa extends Fornecedor{
    #rg
    #cpf
    constructor(nome="Pedro", fone="(00)00000-0000", rg="12.125.123-56", cpf="132.410.123-02") {
        super(nome,fone)
        this.#rg = rg
        this.#cpf = cpf
    }
    setRg(novoRg) {
        this.#rg = novoRg;
    }
    getRg() {
        return this.#rg;
    }
    setCpf(novoCpf) {
        this.#cpf = novoCpf;
    }
    getCpf() {
        return this.#cpf;
    }
}

export default FornecedorPessoa